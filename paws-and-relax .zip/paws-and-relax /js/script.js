// =====================================================
// PAWS & RELAX
// JavaScript + jQuery + JSON + AJAX + API
// =====================================================


// Wait until the HTML page is completely loaded
$(document).ready(function () {


    // =================================================
    // SERVICE DROPDOWN
    // =================================================

    $("#service").change(function () {

        // Hide all sub-service dropdowns
        $(".sub-service").hide();

        // Clear previous selections
        $(".sub-service").val("");


        // Hide all date and time fields
        $(".form-field").hide();


        // Clear date and time values
        $("#date").val("");
        $("#time").val("");
        $("#check-in").val("");
        $("#check-in-time").val("");
        $("#check-out").val("");
        $("#check-out-time").val("");


        // Get the selected service
        let selectedService = $(this).val();


        // =================================================
        // GROOMING
        // =================================================

        if (selectedService === "grooming") {

            // Show grooming options
            $("#grooming-options").show();

        }


        // =================================================
        // SPA
        // =================================================

        else if (selectedService === "spa") {

            // Show spa options
            $("#spa-options").show();

        }


        // =================================================
        // HOSTEL
        // =================================================

        else if (selectedService === "hostel") {

            // Show hostel options
            $("#hostel-options").show();

        }

    });



    // =================================================
    // GROOMING / SPA OPTIONS
    // =================================================

    $("#grooming-options, #spa-options").change(function () {

        // Show ONLY normal Date and Time
        $("#normal-date-field").show();

        $("#normal-time-field").show();

    });



    /// =================================================
    // HOSTEL OPTIONS
// =================================================

$("#hostel-options").change(function () {

    // Hide all date/time fields first
    $(".form-field").hide();


    // Get selected stay type
    let stayType = $(this).val();


    // =================================================
    // DAY STAY
    // =================================================

    if (stayType === "Day Stay") {

        // Show normal Date
        $("#normal-date-field").show();

        // Show Check-in Time
        $("#check-in-time-field").show();

        // Show Check-out Time
        $("#check-out-time-field").show();

    }


    // =================================================
    // OVERNIGHT STAY
    // =================================================

    else if (stayType === "Overnight Stay") {

    // Show Check-in Date
    $("#check-in-date-field").show();

    // Show Check-in Time
    $("#check-in-time-field").show();

    // Show Check-out Date
    $("#check-out-date-field").show();

    // Show Check-out Time
    $("#check-out-time-field").show();


    // Make Check-out Date automatically calculated
    $("#check-out").prop("readonly", true);

}


    // =================================================
    // WEEKEND STAY
    // =================================================

    else if (stayType === "Weekend Stay") {

        // Check-in Date
        $("#check-in-date-field").show();

        // Check-in Time
        $("#check-in-time-field").show();

        // Check-out Date
        $("#check-out-date-field").show();

        // Check-out Time
        $("#check-out-time-field").show();

    }

});
    // =================================================
// OVERNIGHT STAY - AUTO CHECK-OUT DATE
// =================================================

$("#check-in").change(function () {

    // Check if Overnight Stay is selected
    if ($("#hostel-options").val() === "Overnight Stay") {

        // Get the selected check-in date
        let checkInDate = $(this).val();

        if (checkInDate !== "") {

            // Convert the selected date into a Date object
            let date = new Date(checkInDate);

            // Add one day
            date.setDate(date.getDate() + 1);

            // Convert back to YYYY-MM-DD format
            let year = date.getFullYear();

            let month = String(
                date.getMonth() + 1
            ).padStart(2, "0");

            let day = String(
                date.getDate()
            ).padStart(2, "0");


            let checkOutDate =
                year + "-" + month + "-" + day;


            // Automatically fill Check-out Date
            $("#check-out").val(checkOutDate);

        }

    }

}); 



    // =================================================
    // BOOKING FORM
    // =================================================

    $("#booking-form").submit(function (event) {

        // Prevent page refresh
        event.preventDefault();


        // Get basic form values
        let dogName = $("#dog-name").val().trim();

        let ownerName = $("#owner-name").val().trim();

        let phone = $("#phone").val().trim();

        let service = $("#service").val();


        // Get date/time values
        let date = $("#date").val();

        let time = $("#time").val();

        let checkIn = $("#check-in").val();

        let checkInTime = $("#check-in-time").val();

        let checkOut = $("#check-out").val();

        let checkOutTime = $("#check-out-time").val();


        // =================================================
        // GET SUB-SERVICE
        // =================================================

        let subService = "";


        if (service === "grooming") {

            subService = $("#grooming-options").val();

        }

        else if (service === "spa") {

            subService = $("#spa-options").val();

        }

        else if (service === "hostel") {

            subService = $("#hostel-options").val();

        }



        // =================================================
        // BASIC VALIDATION
        // =================================================

        if (
            dogName === "" ||
            ownerName === "" ||
            phone === "" ||
            service === "" ||
            subService === ""
        ) {

            $("#booking-message")
                .text(
                    "Please fill in all the details before booking. 🐾"
                )
                .css("color", "#a05a4b");

            return;

        }



        // =================================================
        // GROOMING / SPA VALIDATION
        // =================================================

        if (
            service === "grooming" ||
            service === "spa"
        ) {

            if (
                date === "" ||
                time === ""
            ) {

                $("#booking-message")
                    .text(
                        "Please select both a date and time. 🐾"
                    )
                    .css("color", "#a05a4b");

                return;

            }

        }



        // =================================================
// HOSTEL VALIDATION
// =================================================

if (service === "hostel") {

    // -------------------------------------------------
    // DAY STAY
    // -------------------------------------------------

    if (subService === "Day Stay") {

        if (
            date === "" ||
            checkInTime === "" ||
            checkOutTime === ""
        ) {

            $("#booking-message")
                .text(
                    "Please select the date, check-in time and check-out time. 🐾"
                )
                .css("color", "#a05a4b");

            return;

        }

    }


    // -------------------------------------------------
    // OVERNIGHT / WEEKEND
    // -------------------------------------------------

    else {

        if (
            checkIn === "" ||
            checkInTime === "" ||
            checkOut === "" ||
            checkOutTime === ""
        ) {

            $("#booking-message")
                .text(
                    "Please select check-in and check-out date and time. 🐾"
                )
                .css("color", "#a05a4b");

            return;

        }


        // Convert dates + times into JavaScript dates
        let checkInDateTime =
            new Date(checkIn + "T" + checkInTime);

        let checkOutDateTime =
            new Date(checkOut + "T" + checkOutTime);


        // -------------------------------------------------
        // CHECK-OUT MUST BE AFTER CHECK-IN
        // -------------------------------------------------

        if (checkOutDateTime <= checkInDateTime) {

            $("#booking-message")
                .text(
                    "Check-out must be after check-in. 🐾"
                )
                .css("color", "#a05a4b");

            return;

        }

    }

}





        // =================================================
        // JSON OBJECT
        // =================================================

        let bookingData = {

            dogName: dogName,

            ownerName: ownerName,

            phone: phone,

            service: service,

            subService: subService,

            date: date,

            time: time,

            checkIn: checkIn,

            checkInTime: checkInTime,

            checkOut: checkOut,

            checkOutTime: checkOutTime

        };


        // Convert JavaScript object into JSON
        let jsonData = JSON.stringify(bookingData);


        console.log("Booking JSON:");

        console.log(jsonData);



        // =================================================
        // AJAX API REQUEST
        // =================================================

        $.ajax({

            url: "https://jsonplaceholder.typicode.com/posts",

            type: "POST",

            contentType: "application/json",

            data: jsonData,


            // =================================================
            // SUCCESS
            // =================================================

            success: function (response) {

                console.log("API Response:");

                console.log(response);


                // Show confirmation
                $("#booking-message")
                    .text(
                        "Booking Confirmed! 🐾 " +
                        dogName +
                        " is booked for " +
                        subService +
                        ". We can't wait to pamper your pup, " +
                        ownerName +
                        "! 🤎"
                    )
                    .css("color", "#76513f");


                // Clear the form
                $("#booking-form")[0].reset();


                // Hide sub-service dropdowns
                $(".sub-service").hide();


                // Hide date/time fields
                $(".form-field").hide();

            },


            // =================================================
            // ERROR
            // =================================================

            error: function () {

                $("#booking-message")
                    .text(
                        "Something went wrong. Please try again. 🐾"
                    )
                    .css("color", "#a05a4b");

            }

        });

    });

});